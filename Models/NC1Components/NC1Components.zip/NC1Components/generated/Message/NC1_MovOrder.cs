using System;
using System.Text;
using System.Collections.Generic;
using com.objsys.xbinder.runtime;
namespace Commun.msg
{
    using System.IO;
   using System.Xml;
   using com.objsys.xbinder.runtime;
    using global::Commun.Common;
    using global::Commun.Commun;
    using global::Commun.Message;

    public class NC1_MovOrder_ELEM_2_B_situation : 
      com.objsys.xbinder.runtime.XBComplexType
   {

      public static readonly  XBQualifiedName XSD_TYPE = new XBQualifiedName("urn:fra:nc1:message:movorder",
          "NC1_MovOrder_ELEM_2_B_situation");

      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static new Object[] particleInfo = {
         new XBQualifiedName("","B1_enemyForces"),
         new XBQualifiedName("","B2_friendlyForces"),
         new XBQualifiedName("","B3_reinforcements"),
         new XBQualifiedName("","B4_situationAssessment")
      };
      static NC1_MovOrder_ELEM_2_B_situation() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //attribute fields

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.
      protected bool elementEmpty = false;

      //content fields
      protected  MixedAnyType b1_enemyForces;   //optional
      protected  MixedAnyType b2_friendlyForces;   //optional
      protected  MixedAnyType b3_reinforcements;   //optional
      protected string b4_situationAssessment;
      protected bool _set_b4_situationAssessment = false;

      //attribute methods

      //content methods

      public  MixedAnyType B1_enemyForces
      {
         get
         {
            if (this.b1_enemyForces == null)
                throw new XBException("field b1_enemyForces not set");

            return this.b1_enemyForces;
         }
         set
         {
            this.b1_enemyForces = value;
         }
      }

      public  MixedAnyType B2_friendlyForces
      {
         get
         {
            if (this.b2_friendlyForces == null)
                throw new XBException("field b2_friendlyForces not set");

            return this.b2_friendlyForces;
         }
         set
         {
            this.b2_friendlyForces = value;
         }
      }

      public  MixedAnyType B3_reinforcements
      {
         get
         {
            if (this.b3_reinforcements == null)
                throw new XBException("field b3_reinforcements not set");

            return this.b3_reinforcements;
         }
         set
         {
            this.b3_reinforcements = value;
         }
      }

      public string B4_situationAssessment
      {
         get
         {
            if (!_set_b4_situationAssessment)
                throw new XBException("field b4_situationAssessment not set");

            return this.b4_situationAssessment;
         }
         set
         {
            this.b4_situationAssessment = value;
            _set_b4_situationAssessment = true;
         }
      }

      /**
       * Validate attributes after decoding.
       * Checks required attributes are set.
       * Assigns missing optional attributes default value.
       *
       * @param _attrPresenceFlags Flags set during decoding.
       */
      protected virtual void validateAttrs(bool[] _attrPresenceFlags){
      }


      protected virtual bool decodeAttr(String name, String ns, String prefix, 
         String text, bool[] _attrPresenceFlags, 
         com.objsys.xbinder.runtime.XBContext xbContext) {
         return false;
      }

      protected virtual void encodeAttrs(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element whose content  is to be decoded.
       * POST: if return is false, reader is on corresponding END_ELEMENT.
       *    if return is true, reader is positioned at first bit of unprocessed content.
       * @param decodeAllContent if true, an error occurs if any content is not decoded by this method.
       *    (ie, the return must be false)
       * @return true if more content remains to be decoded, false otherwise
       */
      protected virtual bool decodeContent(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool decodeAllContent) {
         try  {
            bool moreContent_4;
            if (elementEmpty) {
               moreContent_4 = false;
            }
            else {
               moreContent_4 = XMLStreamHelper.moveToContentElement(reader);
            }
            if ( moreContent_4 ) {
               String elemLocalName = null;
               String elemNs = null;
               elemLocalName = reader.LocalName;
               elemNs = reader.NamespaceURI;

               // b1_enemyForces
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
               {
                  this.b1_enemyForces = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.b1_enemyForces.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // b2_friendlyForces
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[1], elemNs, elemLocalName) )
               {
                  this.b2_friendlyForces = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.b2_friendlyForces.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // b3_reinforcements
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[2], elemNs, elemLocalName) )
               {
                  this.b3_reinforcements = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.b3_reinforcements.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // b4_situationAssessment
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[3], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.b4_situationAssessment =  WideTextType.decode(text, xbContext);

                  _set_b4_situationAssessment = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
               }

               if (decodeAllContent && moreContent_4) 
                  throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
            }
            return moreContent_4;
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode content.
       */
      protected virtual void encodeContent(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         // b1_enemyForces
         if (this.b1_enemyForces != null)  {
            encoder.encodeStartElement("B1_enemyForces", "", "");
            this.b1_enemyForces.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // b2_friendlyForces
         if (this.b2_friendlyForces != null)  {
            encoder.encodeStartElement("B2_friendlyForces", "", "");
            this.b2_friendlyForces.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // b3_reinforcements
         if (this.b3_reinforcements != null)  {
            encoder.encodeStartElement("B3_reinforcements", "", "");
            this.b3_reinforcements.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // b4_situationAssessment
         if (_set_b4_situationAssessment)  {
            encoder.encodeStartElement("B4_situationAssessment", "", "");
            String text_4;
            text_4 =  WideTextType.encode(this.b4_situationAssessment, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       * @param isNilled Pass true if the element was nillable and nilled.
       *       If true, an exception will result if any content is found.
       *       If false, an exception will result if non-emptiable particles
       *       are missing.
       * @param hasDefault Pass true if the element has a default fixed value.
       *       Clients are responsible for validating fixed values.
       *       If false, and isNilled is also false, an exception will result
       *       if no character data is found and no character data is invalid.
       *       If true, missing character data is ignored; you should have
       *       initialized the value field to the default value.
       */
      public virtual void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool isNilled, bool hasDefault) {

         decodeNamespaces(reader);
         elementEmpty = XMLStreamHelper.checkEmptyElement(reader);

         for(bool moreAttr = reader.MoveToFirstAttribute(); moreAttr; 
            moreAttr = reader.MoveToNextAttribute()) {

            String text = reader.Value;
            String ns = reader.NamespaceURI;
            String name = reader.LocalName;
            String prefix = reader.Prefix;

            if (ns.CompareTo("http://www.w3.org/2001/XMLSchema-instance") == 0 ) continue;
            if (ns.CompareTo("http://www.w3.org/2000/xmlns/") == 0 ) continue;
            decodeAttr(name, ns, prefix, text, null, xbContext);
         }
         validateAttrs(null);

         if ( isNilled ) XMLStreamHelper.assertEmptyElement(reader);
         else  {
            decodeContent(reader, xbContext, true);
         }
      }


      /**
       * Encode contents of this class as XML content.
       * Caller should surround this method with calls to encoder.encodeStartElement 
       * and encoder.encodeEndElement.
       * @param elemDeclType if not null, encode xsi:type if this class's
       *    XSD_TYPE does not correspond to elemDeclType.
       * @param ignoreContent if true, do not encode, or validate, character
       *    data or child elements.  Encode an xsi:nil attribute.
       */
      public virtual void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext, 
         XBQualifiedName elemDeclType, bool ignoreContent) {

         encodeNamespaces(encoder);

         if ( elemDeclType != null && !XSD_TYPE.equals(elemDeclType) ) 
            encoder.encodeXsiType(XSD_TYPE);
         encodeAttrs(encoder, xbContext);
         if ( ignoreContent )  {
            encoder.encodeAttr("nil", "http://www.w3.org/2001/XMLSchema-instance", "xsi", "true");
            return;
         }

         encodeContent(encoder, xbContext);
      }
   }

   public class NC1_MovOrder_ELEM_2_D_execution : 
      com.objsys.xbinder.runtime.XBComplexType
   {

      public static readonly  XBQualifiedName XSD_TYPE = new XBQualifiedName("urn:fra:nc1:message:movorder",
          "NC1_MovOrder_ELEM_2_D_execution");

      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static new Object[] particleInfo = {
         new XBQualifiedName("","D1_movmentConception"),
         new XBQualifiedName("","D2_subordinatesUnitsMission"),
         new XBQualifiedName("","D3_timings"),
         new XBQualifiedName("","D4_other")
      };
      static NC1_MovOrder_ELEM_2_D_execution() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //attribute fields

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.
      protected bool elementEmpty = false;

      //content fields
      protected  MixedAnyType d1_movmentConception;   //optional
      protected  MixedAnyType d2_subordinatesUnitsMission;   //optional
      protected string d3_timings;
      protected bool _set_d3_timings = false;
      protected  MixedAnyType d4_other;   //optional

      //attribute methods

      //content methods

      public  MixedAnyType D1_movmentConception
      {
         get
         {
            if (this.d1_movmentConception == null)
                throw new XBException("field d1_movmentConception not set");

            return this.d1_movmentConception;
         }
         set
         {
            this.d1_movmentConception = value;
         }
      }

      public  MixedAnyType D2_subordinatesUnitsMission
      {
         get
         {
            if (this.d2_subordinatesUnitsMission == null)
                throw new XBException("field d2_subordinatesUnitsMission not set");

            return this.d2_subordinatesUnitsMission;
         }
         set
         {
            this.d2_subordinatesUnitsMission = value;
         }
      }

      public string D3_timings
      {
         get
         {
            if (!_set_d3_timings)
                throw new XBException("field d3_timings not set");

            return this.d3_timings;
         }
         set
         {
            this.d3_timings = value;
            _set_d3_timings = true;
         }
      }

      public  MixedAnyType D4_other
      {
         get
         {
            if (this.d4_other == null)
                throw new XBException("field d4_other not set");

            return this.d4_other;
         }
         set
         {
            this.d4_other = value;
         }
      }

      /**
       * Validate attributes after decoding.
       * Checks required attributes are set.
       * Assigns missing optional attributes default value.
       *
       * @param _attrPresenceFlags Flags set during decoding.
       */
      protected virtual void validateAttrs(bool[] _attrPresenceFlags){
      }


      protected virtual bool decodeAttr(String name, String ns, String prefix, 
         String text, bool[] _attrPresenceFlags, 
         com.objsys.xbinder.runtime.XBContext xbContext) {
         return false;
      }

      protected virtual void encodeAttrs(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element whose content  is to be decoded.
       * POST: if return is false, reader is on corresponding END_ELEMENT.
       *    if return is true, reader is positioned at first bit of unprocessed content.
       * @param decodeAllContent if true, an error occurs if any content is not decoded by this method.
       *    (ie, the return must be false)
       * @return true if more content remains to be decoded, false otherwise
       */
      protected virtual bool decodeContent(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool decodeAllContent) {
         try  {
            bool moreContent_4;
            if (elementEmpty) {
               moreContent_4 = false;
            }
            else {
               moreContent_4 = XMLStreamHelper.moveToContentElement(reader);
            }
            if ( moreContent_4 ) {
               String elemLocalName = null;
               String elemNs = null;
               elemLocalName = reader.LocalName;
               elemNs = reader.NamespaceURI;

               // d1_movmentConception
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
               {
                  this.d1_movmentConception = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.d1_movmentConception.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // d2_subordinatesUnitsMission
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[1], elemNs, elemLocalName) )
               {
                  this.d2_subordinatesUnitsMission = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.d2_subordinatesUnitsMission.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // d3_timings
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[2], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.d3_timings =  WideTextType.decode(text, xbContext);

                  _set_d3_timings = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // d4_other
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[3], elemNs, elemLocalName) )
               {
                  this.d4_other = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.d4_other.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
               }

               if (decodeAllContent && moreContent_4) 
                  throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
            }
            return moreContent_4;
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode content.
       */
      protected virtual void encodeContent(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         // d1_movmentConception
         if (this.d1_movmentConception != null)  {
            encoder.encodeStartElement("D1_movmentConception", "", "");
            this.d1_movmentConception.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // d2_subordinatesUnitsMission
         if (this.d2_subordinatesUnitsMission != null)  {
            encoder.encodeStartElement("D2_subordinatesUnitsMission", "", "");
            this.d2_subordinatesUnitsMission.encode(encoder, xbContext, null, 
               false);
            encoder.encodeEndElement();
         }

         // d3_timings
         if (_set_d3_timings)  {
            encoder.encodeStartElement("D3_timings", "", "");
            String text_4;
            text_4 =  WideTextType.encode(this.d3_timings, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }

         // d4_other
         if (this.d4_other != null)  {
            encoder.encodeStartElement("D4_other", "", "");
            this.d4_other.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       * @param isNilled Pass true if the element was nillable and nilled.
       *       If true, an exception will result if any content is found.
       *       If false, an exception will result if non-emptiable particles
       *       are missing.
       * @param hasDefault Pass true if the element has a default fixed value.
       *       Clients are responsible for validating fixed values.
       *       If false, and isNilled is also false, an exception will result
       *       if no character data is found and no character data is invalid.
       *       If true, missing character data is ignored; you should have
       *       initialized the value field to the default value.
       */
      public virtual void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool isNilled, bool hasDefault) {

         decodeNamespaces(reader);
         elementEmpty = XMLStreamHelper.checkEmptyElement(reader);

         for(bool moreAttr = reader.MoveToFirstAttribute(); moreAttr; 
            moreAttr = reader.MoveToNextAttribute()) {

            String text = reader.Value;
            String ns = reader.NamespaceURI;
            String name = reader.LocalName;
            String prefix = reader.Prefix;

            if (ns.CompareTo("http://www.w3.org/2001/XMLSchema-instance") == 0 ) continue;
            if (ns.CompareTo("http://www.w3.org/2000/xmlns/") == 0 ) continue;
            decodeAttr(name, ns, prefix, text, null, xbContext);
         }
         validateAttrs(null);

         if ( isNilled ) XMLStreamHelper.assertEmptyElement(reader);
         else  {
            decodeContent(reader, xbContext, true);
         }
      }


      /**
       * Encode contents of this class as XML content.
       * Caller should surround this method with calls to encoder.encodeStartElement 
       * and encoder.encodeEndElement.
       * @param elemDeclType if not null, encode xsi:type if this class's
       *    XSD_TYPE does not correspond to elemDeclType.
       * @param ignoreContent if true, do not encode, or validate, character
       *    data or child elements.  Encode an xsi:nil attribute.
       */
      public virtual void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext, 
         XBQualifiedName elemDeclType, bool ignoreContent) {

         encodeNamespaces(encoder);

         if ( elemDeclType != null && !XSD_TYPE.equals(elemDeclType) ) 
            encoder.encodeXsiType(XSD_TYPE);
         encodeAttrs(encoder, xbContext);
         if ( ignoreContent )  {
            encoder.encodeAttr("nil", "http://www.w3.org/2001/XMLSchema-instance", "xsi", "true");
            return;
         }

         encodeContent(encoder, xbContext);
      }
   }

   public class NC1_MovOrder_ELEM_2_E_coordinationInstructions : 
      com.objsys.xbinder.runtime.XBComplexType
   {

      public static readonly  XBQualifiedName XSD_TYPE = new XBQualifiedName("urn:fra:nc1:message:movorder",
          "NC1_MovOrder_ELEM_2_E_coordinationInstructions");

      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static new Object[] particleInfo = {
         new XBQualifiedName("","E1_marchColumn"),
         new XBQualifiedName("","E2_routes"),
         new XBQualifiedName("","E3_density"),
         new XBQualifiedName("","E4_speed"),
         new XBQualifiedName("","E5_movmentMethod"),
         new XBQualifiedName("","E6_movmentDefence"),
         new XBQualifiedName("","E7_points"),
         new XBQualifiedName("","E8_convoyControl"),
         new XBQualifiedName("","E9_transitAccommodationAreas"),
         new XBQualifiedName("","E10_halts"),
         new XBQualifiedName("","E11_lights"),
         new XBQualifiedName("","E12_airSupport")
      };
      static NC1_MovOrder_ELEM_2_E_coordinationInstructions() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //attribute fields

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.
      protected bool elementEmpty = false;

      //content fields
      protected  MixedAnyType e1_marchColumn;   //optional
      protected  MixedAnyType e2_routes;   //optional
      protected string e3_density;
      protected bool _set_e3_density = false;
      protected string e4_speed;
      protected bool _set_e4_speed = false;
      protected  MixedAnyType e5_movmentMethod;   //optional
      protected  MixedAnyType e6_movmentDefence;   //optional
      protected  MixedAnyType e7_points;   //optional
      protected  MixedAnyType e8_convoyControl;   //optional
      protected  MixedAnyType e9_transitAccommodationAreas;   //optional
      protected string e10_halts;
      protected bool _set_e10_halts = false;
      protected string e11_lights;
      protected bool _set_e11_lights = false;
      protected  MixedAnyType e12_airSupport;   //optional

      //attribute methods

      //content methods

      public  MixedAnyType E1_marchColumn
      {
         get
         {
            if (this.e1_marchColumn == null)
                throw new XBException("field e1_marchColumn not set");

            return this.e1_marchColumn;
         }
         set
         {
            this.e1_marchColumn = value;
         }
      }

      public  MixedAnyType E2_routes
      {
         get
         {
            if (this.e2_routes == null)
                throw new XBException("field e2_routes not set");

            return this.e2_routes;
         }
         set
         {
            this.e2_routes = value;
         }
      }

      public string E3_density
      {
         get
         {
            if (!_set_e3_density)
                throw new XBException("field e3_density not set");

            return this.e3_density;
         }
         set
         {
            this.e3_density = value;
            _set_e3_density = true;
         }
      }

      public string E4_speed
      {
         get
         {
            if (!_set_e4_speed)
                throw new XBException("field e4_speed not set");

            return this.e4_speed;
         }
         set
         {
            this.e4_speed = value;
            _set_e4_speed = true;
         }
      }

      public  MixedAnyType E5_movmentMethod
      {
         get
         {
            if (this.e5_movmentMethod == null)
                throw new XBException("field e5_movmentMethod not set");

            return this.e5_movmentMethod;
         }
         set
         {
            this.e5_movmentMethod = value;
         }
      }

      public  MixedAnyType E6_movmentDefence
      {
         get
         {
            if (this.e6_movmentDefence == null)
                throw new XBException("field e6_movmentDefence not set");

            return this.e6_movmentDefence;
         }
         set
         {
            this.e6_movmentDefence = value;
         }
      }

      public  MixedAnyType E7_points
      {
         get
         {
            if (this.e7_points == null)
                throw new XBException("field e7_points not set");

            return this.e7_points;
         }
         set
         {
            this.e7_points = value;
         }
      }

      public  MixedAnyType E8_convoyControl
      {
         get
         {
            if (this.e8_convoyControl == null)
                throw new XBException("field e8_convoyControl not set");

            return this.e8_convoyControl;
         }
         set
         {
            this.e8_convoyControl = value;
         }
      }

      public  MixedAnyType E9_transitAccommodationAreas
      {
         get
         {
            if (this.e9_transitAccommodationAreas == null)
                throw new XBException("field e9_transitAccommodationAreas not set");

            return this.e9_transitAccommodationAreas;
         }
         set
         {
            this.e9_transitAccommodationAreas = value;
         }
      }

      public string E10_halts
      {
         get
         {
            if (!_set_e10_halts)
                throw new XBException("field e10_halts not set");

            return this.e10_halts;
         }
         set
         {
            this.e10_halts = value;
            _set_e10_halts = true;
         }
      }

      public string E11_lights
      {
         get
         {
            if (!_set_e11_lights)
                throw new XBException("field e11_lights not set");

            return this.e11_lights;
         }
         set
         {
            this.e11_lights = value;
            _set_e11_lights = true;
         }
      }

      public  MixedAnyType E12_airSupport
      {
         get
         {
            if (this.e12_airSupport == null)
                throw new XBException("field e12_airSupport not set");

            return this.e12_airSupport;
         }
         set
         {
            this.e12_airSupport = value;
         }
      }

      /**
       * Validate attributes after decoding.
       * Checks required attributes are set.
       * Assigns missing optional attributes default value.
       *
       * @param _attrPresenceFlags Flags set during decoding.
       */
      protected virtual void validateAttrs(bool[] _attrPresenceFlags){
      }


      protected virtual bool decodeAttr(String name, String ns, String prefix, 
         String text, bool[] _attrPresenceFlags, 
         com.objsys.xbinder.runtime.XBContext xbContext) {
         return false;
      }

      protected virtual void encodeAttrs(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element whose content  is to be decoded.
       * POST: if return is false, reader is on corresponding END_ELEMENT.
       *    if return is true, reader is positioned at first bit of unprocessed content.
       * @param decodeAllContent if true, an error occurs if any content is not decoded by this method.
       *    (ie, the return must be false)
       * @return true if more content remains to be decoded, false otherwise
       */
      protected virtual bool decodeContent(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool decodeAllContent) {
         try  {
            bool moreContent_4;
            if (elementEmpty) {
               moreContent_4 = false;
            }
            else {
               moreContent_4 = XMLStreamHelper.moveToContentElement(reader);
            }
            if ( moreContent_4 ) {
               String elemLocalName = null;
               String elemNs = null;
               elemLocalName = reader.LocalName;
               elemNs = reader.NamespaceURI;

               // e1_marchColumn
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
               {
                  this.e1_marchColumn = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e1_marchColumn.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e2_routes
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[1], elemNs, elemLocalName) )
               {
                  this.e2_routes = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e2_routes.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e3_density
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[2], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.e3_density =  LongTextType.decode(text, xbContext);

                  _set_e3_density = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e4_speed
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[3], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.e4_speed =  LongTextType.decode(text, xbContext);

                  _set_e4_speed = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e5_movmentMethod
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[4], elemNs, elemLocalName) )
               {
                  this.e5_movmentMethod = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e5_movmentMethod.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e6_movmentDefence
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[5], elemNs, elemLocalName) )
               {
                  this.e6_movmentDefence = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e6_movmentDefence.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e7_points
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[6], elemNs, elemLocalName) )
               {
                  this.e7_points = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e7_points.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e8_convoyControl
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[7], elemNs, elemLocalName) )
               {
                  this.e8_convoyControl = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e8_convoyControl.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e9_transitAccommodationAreas
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[8], elemNs, elemLocalName) )
               {
                  this.e9_transitAccommodationAreas = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e9_transitAccommodationAreas.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e10_halts
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[9], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.e10_halts =  WideTextType.decode(text, xbContext);

                  _set_e10_halts = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e11_lights
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[10], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.e11_lights =  LongTextType.decode(text, xbContext);

                  _set_e11_lights = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e12_airSupport
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[11], elemNs, elemLocalName) )
               {
                  this.e12_airSupport = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e12_airSupport.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
               }

               if (decodeAllContent && moreContent_4) 
                  throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
            }
            return moreContent_4;
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode content.
       */
      protected virtual void encodeContent(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         // e1_marchColumn
         if (this.e1_marchColumn != null)  {
            encoder.encodeStartElement("E1_marchColumn", "", "");
            this.e1_marchColumn.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e2_routes
         if (this.e2_routes != null)  {
            encoder.encodeStartElement("E2_routes", "", "");
            this.e2_routes.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e3_density
         if (_set_e3_density)  {
            encoder.encodeStartElement("E3_density", "", "");
            String text_4;
            text_4 =  LongTextType.encode(this.e3_density, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }

         // e4_speed
         if (_set_e4_speed)  {
            encoder.encodeStartElement("E4_speed", "", "");
            String text_4;
            text_4 =  LongTextType.encode(this.e4_speed, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }

         // e5_movmentMethod
         if (this.e5_movmentMethod != null)  {
            encoder.encodeStartElement("E5_movmentMethod", "", "");
            this.e5_movmentMethod.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e6_movmentDefence
         if (this.e6_movmentDefence != null)  {
            encoder.encodeStartElement("E6_movmentDefence", "", "");
            this.e6_movmentDefence.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e7_points
         if (this.e7_points != null)  {
            encoder.encodeStartElement("E7_points", "", "");
            this.e7_points.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e8_convoyControl
         if (this.e8_convoyControl != null)  {
            encoder.encodeStartElement("E8_convoyControl", "", "");
            this.e8_convoyControl.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e9_transitAccommodationAreas
         if (this.e9_transitAccommodationAreas != null)  {
            encoder.encodeStartElement("E9_transitAccommodationAreas", "", "");
            this.e9_transitAccommodationAreas.encode(encoder, xbContext, null, 
               false);
            encoder.encodeEndElement();
         }

         // e10_halts
         if (_set_e10_halts)  {
            encoder.encodeStartElement("E10_halts", "", "");
            String text_4;
            text_4 =  WideTextType.encode(this.e10_halts, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }

         // e11_lights
         if (_set_e11_lights)  {
            encoder.encodeStartElement("E11_lights", "", "");
            String text_4;
            text_4 =  LongTextType.encode(this.e11_lights, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }

         // e12_airSupport
         if (this.e12_airSupport != null)  {
            encoder.encodeStartElement("E12_airSupport", "", "");
            this.e12_airSupport.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       * @param isNilled Pass true if the element was nillable and nilled.
       *       If true, an exception will result if any content is found.
       *       If false, an exception will result if non-emptiable particles
       *       are missing.
       * @param hasDefault Pass true if the element has a default fixed value.
       *       Clients are responsible for validating fixed values.
       *       If false, and isNilled is also false, an exception will result
       *       if no character data is found and no character data is invalid.
       *       If true, missing character data is ignored; you should have
       *       initialized the value field to the default value.
       */
      public virtual void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool isNilled, bool hasDefault) {

         decodeNamespaces(reader);
         elementEmpty = XMLStreamHelper.checkEmptyElement(reader);

         for(bool moreAttr = reader.MoveToFirstAttribute(); moreAttr; 
            moreAttr = reader.MoveToNextAttribute()) {

            String text = reader.Value;
            String ns = reader.NamespaceURI;
            String name = reader.LocalName;
            String prefix = reader.Prefix;

            if (ns.CompareTo("http://www.w3.org/2001/XMLSchema-instance") == 0 ) continue;
            if (ns.CompareTo("http://www.w3.org/2000/xmlns/") == 0 ) continue;
            decodeAttr(name, ns, prefix, text, null, xbContext);
         }
         validateAttrs(null);

         if ( isNilled ) XMLStreamHelper.assertEmptyElement(reader);
         else  {
            decodeContent(reader, xbContext, true);
         }
      }


      /**
       * Encode contents of this class as XML content.
       * Caller should surround this method with calls to encoder.encodeStartElement 
       * and encoder.encodeEndElement.
       * @param elemDeclType if not null, encode xsi:type if this class's
       *    XSD_TYPE does not correspond to elemDeclType.
       * @param ignoreContent if true, do not encode, or validate, character
       *    data or child elements.  Encode an xsi:nil attribute.
       */
      public virtual void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext, 
         XBQualifiedName elemDeclType, bool ignoreContent) {

         encodeNamespaces(encoder);

         if ( elemDeclType != null && !XSD_TYPE.equals(elemDeclType) ) 
            encoder.encodeXsiType(XSD_TYPE);
         encodeAttrs(encoder, xbContext);
         if ( ignoreContent )  {
            encoder.encodeAttr("nil", "http://www.w3.org/2001/XMLSchema-instance", "xsi", "true");
            return;
         }

         encodeContent(encoder, xbContext);
      }
   }

   public class NC1_MovOrder_ELEM_2_F_logisticsSupport : 
      com.objsys.xbinder.runtime.XBComplexType
   {

      public static readonly  XBQualifiedName XSD_TYPE = new XBQualifiedName("urn:fra:nc1:message:movorder",
          "NC1_MovOrder_ELEM_2_F_logisticsSupport");

      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static new Object[] particleInfo = {
         new XBQualifiedName("","F1_situationControl"),
         new XBQualifiedName("","F2_recovery"),
         new XBQualifiedName("","F3_medical"),
         new XBQualifiedName("","F4_POL"),
         new XBQualifiedName("","F5_water")
      };
      static NC1_MovOrder_ELEM_2_F_logisticsSupport() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //attribute fields

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.
      protected bool elementEmpty = false;

      //content fields
      protected  MixedAnyType f1_situationControl;   //optional
      protected  MixedAnyType f2_recovery;   //optional
      protected  MixedAnyType f3_medical;   //optional
      protected  MixedAnyType f4_POL;   //optional
      protected  MixedAnyType f5_water;   //optional

      //attribute methods

      //content methods

      public  MixedAnyType F1_situationControl
      {
         get
         {
            if (this.f1_situationControl == null)
                throw new XBException("field f1_situationControl not set");

            return this.f1_situationControl;
         }
         set
         {
            this.f1_situationControl = value;
         }
      }

      public  MixedAnyType F2_recovery
      {
         get
         {
            if (this.f2_recovery == null)
                throw new XBException("field f2_recovery not set");

            return this.f2_recovery;
         }
         set
         {
            this.f2_recovery = value;
         }
      }

      public  MixedAnyType F3_medical
      {
         get
         {
            if (this.f3_medical == null)
                throw new XBException("field f3_medical not set");

            return this.f3_medical;
         }
         set
         {
            this.f3_medical = value;
         }
      }

      public  MixedAnyType F4_POL
      {
         get
         {
            if (this.f4_POL == null)
                throw new XBException("field f4_POL not set");

            return this.f4_POL;
         }
         set
         {
            this.f4_POL = value;
         }
      }

      public  MixedAnyType F5_water
      {
         get
         {
            if (this.f5_water == null)
                throw new XBException("field f5_water not set");

            return this.f5_water;
         }
         set
         {
            this.f5_water = value;
         }
      }

      /**
       * Validate attributes after decoding.
       * Checks required attributes are set.
       * Assigns missing optional attributes default value.
       *
       * @param _attrPresenceFlags Flags set during decoding.
       */
      protected virtual void validateAttrs(bool[] _attrPresenceFlags){
      }


      protected virtual bool decodeAttr(String name, String ns, String prefix, 
         String text, bool[] _attrPresenceFlags, 
         com.objsys.xbinder.runtime.XBContext xbContext) {
         return false;
      }

      protected virtual void encodeAttrs(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element whose content  is to be decoded.
       * POST: if return is false, reader is on corresponding END_ELEMENT.
       *    if return is true, reader is positioned at first bit of unprocessed content.
       * @param decodeAllContent if true, an error occurs if any content is not decoded by this method.
       *    (ie, the return must be false)
       * @return true if more content remains to be decoded, false otherwise
       */
      protected virtual bool decodeContent(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool decodeAllContent) {
         try  {
            bool moreContent_4;
            if (elementEmpty) {
               moreContent_4 = false;
            }
            else {
               moreContent_4 = XMLStreamHelper.moveToContentElement(reader);
            }
            if ( moreContent_4 ) {
               String elemLocalName = null;
               String elemNs = null;
               elemLocalName = reader.LocalName;
               elemNs = reader.NamespaceURI;

               // f1_situationControl
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
               {
                  this.f1_situationControl = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.f1_situationControl.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // f2_recovery
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[1], elemNs, elemLocalName) )
               {
                  this.f2_recovery = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.f2_recovery.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // f3_medical
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[2], elemNs, elemLocalName) )
               {
                  this.f3_medical = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.f3_medical.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // f4_POL
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[3], elemNs, elemLocalName) )
               {
                  this.f4_POL = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.f4_POL.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // f5_water
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[4], elemNs, elemLocalName) )
               {
                  this.f5_water = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.f5_water.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
               }

               if (decodeAllContent && moreContent_4) 
                  throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
            }
            return moreContent_4;
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode content.
       */
      protected virtual void encodeContent(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         // f1_situationControl
         if (this.f1_situationControl != null)  {
            encoder.encodeStartElement("F1_situationControl", "", "");
            this.f1_situationControl.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // f2_recovery
         if (this.f2_recovery != null)  {
            encoder.encodeStartElement("F2_recovery", "", "");
            this.f2_recovery.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // f3_medical
         if (this.f3_medical != null)  {
            encoder.encodeStartElement("F3_medical", "", "");
            this.f3_medical.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // f4_POL
         if (this.f4_POL != null)  {
            encoder.encodeStartElement("F4_POL", "", "");
            this.f4_POL.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // f5_water
         if (this.f5_water != null)  {
            encoder.encodeStartElement("F5_water", "", "");
            this.f5_water.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       * @param isNilled Pass true if the element was nillable and nilled.
       *       If true, an exception will result if any content is found.
       *       If false, an exception will result if non-emptiable particles
       *       are missing.
       * @param hasDefault Pass true if the element has a default fixed value.
       *       Clients are responsible for validating fixed values.
       *       If false, and isNilled is also false, an exception will result
       *       if no character data is found and no character data is invalid.
       *       If true, missing character data is ignored; you should have
       *       initialized the value field to the default value.
       */
      public virtual void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool isNilled, bool hasDefault) {

         decodeNamespaces(reader);
         elementEmpty = XMLStreamHelper.checkEmptyElement(reader);

         for(bool moreAttr = reader.MoveToFirstAttribute(); moreAttr; 
            moreAttr = reader.MoveToNextAttribute()) {

            String text = reader.Value;
            String ns = reader.NamespaceURI;
            String name = reader.LocalName;
            String prefix = reader.Prefix;

            if (ns.CompareTo("http://www.w3.org/2001/XMLSchema-instance") == 0 ) continue;
            if (ns.CompareTo("http://www.w3.org/2000/xmlns/") == 0 ) continue;
            decodeAttr(name, ns, prefix, text, null, xbContext);
         }
         validateAttrs(null);

         if ( isNilled ) XMLStreamHelper.assertEmptyElement(reader);
         else  {
            decodeContent(reader, xbContext, true);
         }
      }


      /**
       * Encode contents of this class as XML content.
       * Caller should surround this method with calls to encoder.encodeStartElement 
       * and encoder.encodeEndElement.
       * @param elemDeclType if not null, encode xsi:type if this class's
       *    XSD_TYPE does not correspond to elemDeclType.
       * @param ignoreContent if true, do not encode, or validate, character
       *    data or child elements.  Encode an xsi:nil attribute.
       */
      public virtual void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext, 
         XBQualifiedName elemDeclType, bool ignoreContent) {

         encodeNamespaces(encoder);

         if ( elemDeclType != null && !XSD_TYPE.equals(elemDeclType) ) 
            encoder.encodeXsiType(XSD_TYPE);
         encodeAttrs(encoder, xbContext);
         if ( ignoreContent )  {
            encoder.encodeAttr("nil", "http://www.w3.org/2001/XMLSchema-instance", "xsi", "true");
            return;
         }

         encodeContent(encoder, xbContext);
      }
   }

   public class NC1_MovOrder_ELEM_2_G_commandAndTransmissions : 
      com.objsys.xbinder.runtime.XBComplexType
   {

      public static readonly  XBQualifiedName XSD_TYPE = new XBQualifiedName("urn:fra:nc1:message:movorder",
          "NC1_MovOrder_ELEM_2_G_commandAndTransmissions");

      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static new Object[] particleInfo = {
         new XBQualifiedName("","G1_command"),
         new XBQualifiedName("","G2_links"),
         new XBQualifiedName("","G3_specialVehiclesLocation")
      };
      static NC1_MovOrder_ELEM_2_G_commandAndTransmissions() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //attribute fields

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.
      protected bool elementEmpty = false;

      //content fields
      protected  MixedAnyType g1_command;   //optional
      protected  MixedAnyType g2_links;   //optional
      protected  MixedAnyType g3_specialVehiclesLocation;   //optional

      //attribute methods

      //content methods

      public  MixedAnyType G1_command
      {
         get
         {
            if (this.g1_command == null)
                throw new XBException("field g1_command not set");

            return this.g1_command;
         }
         set
         {
            this.g1_command = value;
         }
      }

      public  MixedAnyType G2_links
      {
         get
         {
            if (this.g2_links == null)
                throw new XBException("field g2_links not set");

            return this.g2_links;
         }
         set
         {
            this.g2_links = value;
         }
      }

      public  MixedAnyType G3_specialVehiclesLocation
      {
         get
         {
            if (this.g3_specialVehiclesLocation == null)
                throw new XBException("field g3_specialVehiclesLocation not set");

            return this.g3_specialVehiclesLocation;
         }
         set
         {
            this.g3_specialVehiclesLocation = value;
         }
      }

      /**
       * Validate attributes after decoding.
       * Checks required attributes are set.
       * Assigns missing optional attributes default value.
       *
       * @param _attrPresenceFlags Flags set during decoding.
       */
      protected virtual void validateAttrs(bool[] _attrPresenceFlags){
      }


      protected virtual bool decodeAttr(String name, String ns, String prefix, 
         String text, bool[] _attrPresenceFlags, 
         com.objsys.xbinder.runtime.XBContext xbContext) {
         return false;
      }

      protected virtual void encodeAttrs(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element whose content  is to be decoded.
       * POST: if return is false, reader is on corresponding END_ELEMENT.
       *    if return is true, reader is positioned at first bit of unprocessed content.
       * @param decodeAllContent if true, an error occurs if any content is not decoded by this method.
       *    (ie, the return must be false)
       * @return true if more content remains to be decoded, false otherwise
       */
      protected virtual bool decodeContent(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool decodeAllContent) {
         try  {
            bool moreContent_4;
            if (elementEmpty) {
               moreContent_4 = false;
            }
            else {
               moreContent_4 = XMLStreamHelper.moveToContentElement(reader);
            }
            if ( moreContent_4 ) {
               String elemLocalName = null;
               String elemNs = null;
               elemLocalName = reader.LocalName;
               elemNs = reader.NamespaceURI;

               // g1_command
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
               {
                  this.g1_command = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.g1_command.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // g2_links
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[1], elemNs, elemLocalName) )
               {
                  this.g2_links = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.g2_links.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // g3_specialVehiclesLocation
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[2], elemNs, elemLocalName) )
               {
                  this.g3_specialVehiclesLocation = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.g3_specialVehiclesLocation.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
               }

               if (decodeAllContent && moreContent_4) 
                  throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
            }
            return moreContent_4;
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode content.
       */
      protected virtual void encodeContent(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         // g1_command
         if (this.g1_command != null)  {
            encoder.encodeStartElement("G1_command", "", "");
            this.g1_command.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // g2_links
         if (this.g2_links != null)  {
            encoder.encodeStartElement("G2_links", "", "");
            this.g2_links.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // g3_specialVehiclesLocation
         if (this.g3_specialVehiclesLocation != null)  {
            encoder.encodeStartElement("G3_specialVehiclesLocation", "", "");
            this.g3_specialVehiclesLocation.encode(encoder, xbContext, null, 
               false);
            encoder.encodeEndElement();
         }
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       * @param isNilled Pass true if the element was nillable and nilled.
       *       If true, an exception will result if any content is found.
       *       If false, an exception will result if non-emptiable particles
       *       are missing.
       * @param hasDefault Pass true if the element has a default fixed value.
       *       Clients are responsible for validating fixed values.
       *       If false, and isNilled is also false, an exception will result
       *       if no character data is found and no character data is invalid.
       *       If true, missing character data is ignored; you should have
       *       initialized the value field to the default value.
       */
      public virtual void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool isNilled, bool hasDefault) {

         decodeNamespaces(reader);
         elementEmpty = XMLStreamHelper.checkEmptyElement(reader);

         for(bool moreAttr = reader.MoveToFirstAttribute(); moreAttr; 
            moreAttr = reader.MoveToNextAttribute()) {

            String text = reader.Value;
            String ns = reader.NamespaceURI;
            String name = reader.LocalName;
            String prefix = reader.Prefix;

            if (ns.CompareTo("http://www.w3.org/2001/XMLSchema-instance") == 0 ) continue;
            if (ns.CompareTo("http://www.w3.org/2000/xmlns/") == 0 ) continue;
            decodeAttr(name, ns, prefix, text, null, xbContext);
         }
         validateAttrs(null);

         if ( isNilled ) XMLStreamHelper.assertEmptyElement(reader);
         else  {
            decodeContent(reader, xbContext, true);
         }
      }


      /**
       * Encode contents of this class as XML content.
       * Caller should surround this method with calls to encoder.encodeStartElement 
       * and encoder.encodeEndElement.
       * @param elemDeclType if not null, encode xsi:type if this class's
       *    XSD_TYPE does not correspond to elemDeclType.
       * @param ignoreContent if true, do not encode, or validate, character
       *    data or child elements.  Encode an xsi:nil attribute.
       */
      public virtual void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext, 
         XBQualifiedName elemDeclType, bool ignoreContent) {

         encodeNamespaces(encoder);

         if ( elemDeclType != null && !XSD_TYPE.equals(elemDeclType) ) 
            encoder.encodeXsiType(XSD_TYPE);
         encodeAttrs(encoder, xbContext);
         if ( ignoreContent )  {
            encoder.encodeAttr("nil", "http://www.w3.org/2001/XMLSchema-instance", "xsi", "true");
            return;
         }

         encodeContent(encoder, xbContext);
      }
   }

   public class NC1_MovOrder_ELEM :  BaseMessageType
   {

      public static readonly new XBQualifiedName XSD_TYPE = new XBQualifiedName("urn:fra:nc1:message:movorder",
          "NC1_MovOrder_ELEM");

      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static new Object[] particleInfo = {
         new XBQualifiedName("","A_movementOrderId"),
         new XBQualifiedName("","B_situation"),
         new XBQualifiedName("","C_mission"),
         new XBQualifiedName("","D_execution"),
         new XBQualifiedName("","E_coordinationInstructions"),
         new XBQualifiedName("","F_logisticsSupport"),
         new XBQualifiedName("","G_commandAndTransmissions"),
         new XBQualifiedName("","H_comment"),
         new XBQualifiedName("","J_drafterUnitPoc")
      };
      static NC1_MovOrder_ELEM() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //attribute fields

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.

      //content fields
      protected string a_movementOrderId;
      protected bool _set_a_movementOrderId = false;
      protected  NC1_MovOrder_ELEM_2_B_situation b_situation;
            //optional
      protected  MixedAnyType c_mission;   //optional
      protected  NC1_MovOrder_ELEM_2_D_execution d_execution;
            //optional
      protected  NC1_MovOrder_ELEM_2_E_coordinationInstructions e_coordinationInstructions;
            //optional
      protected  NC1_MovOrder_ELEM_2_F_logisticsSupport f_logisticsSupport;
            //optional
      protected  NC1_MovOrder_ELEM_2_G_commandAndTransmissions g_commandAndTransmissions;
            //optional
      protected  CommentSectionType h_comment;   //optional
      protected  MixedAnyType j_drafterUnitPoc;   //optional

      //attribute methods

      //content methods

      public string A_movementOrderId
      {
         get
         {
            if (!_set_a_movementOrderId)
                throw new XBException("field a_movementOrderId not set");

            return this.a_movementOrderId;
         }
         set
         {
            this.a_movementOrderId = value;
            _set_a_movementOrderId = true;
         }
      }

      public  NC1_MovOrder_ELEM_2_B_situation B_situation
      {
         get
         {
            if (this.b_situation == null)
                throw new XBException("field b_situation not set");

            return this.b_situation;
         }
         set
         {
            this.b_situation = value;
         }
      }

      public  MixedAnyType C_mission
      {
         get
         {
            if (this.c_mission == null)
                throw new XBException("field c_mission not set");

            return this.c_mission;
         }
         set
         {
            this.c_mission = value;
         }
      }

      public  NC1_MovOrder_ELEM_2_D_execution D_execution
      {
         get
         {
            if (this.d_execution == null)
                throw new XBException("field d_execution not set");

            return this.d_execution;
         }
         set
         {
            this.d_execution = value;
         }
      }

      public  NC1_MovOrder_ELEM_2_E_coordinationInstructions E_coordinationInstructions
      {
         get
         {
            if (this.e_coordinationInstructions == null)
                throw new XBException("field e_coordinationInstructions not set");

            return this.e_coordinationInstructions;
         }
         set
         {
            this.e_coordinationInstructions = value;
         }
      }

      public  NC1_MovOrder_ELEM_2_F_logisticsSupport F_logisticsSupport
      {
         get
         {
            if (this.f_logisticsSupport == null)
                throw new XBException("field f_logisticsSupport not set");

            return this.f_logisticsSupport;
         }
         set
         {
            this.f_logisticsSupport = value;
         }
      }

      public  NC1_MovOrder_ELEM_2_G_commandAndTransmissions G_commandAndTransmissions
      {
         get
         {
            if (this.g_commandAndTransmissions == null)
                throw new XBException("field g_commandAndTransmissions not set");

            return this.g_commandAndTransmissions;
         }
         set
         {
            this.g_commandAndTransmissions = value;
         }
      }

      public  CommentSectionType H_comment
      {
         get
         {
            if (this.h_comment == null)
                throw new XBException("field h_comment not set");

            return this.h_comment;
         }
         set
         {
            this.h_comment = value;
         }
      }

      public  MixedAnyType J_drafterUnitPoc
      {
         get
         {
            if (this.j_drafterUnitPoc == null)
                throw new XBException("field j_drafterUnitPoc not set");

            return this.j_drafterUnitPoc;
         }
         set
         {
            this.j_drafterUnitPoc = value;
         }
      }

      /**
       * Validate attributes after decoding.
       * Checks required attributes are set.
       * Assigns missing optional attributes default value.
       *
       * @param _attrPresenceFlags Flags set during decoding.
       */
      protected override void validateAttrs(bool[] _attrPresenceFlags){
         base.validateAttrs(_attrPresenceFlags);
      }


      protected override bool decodeAttr(String name, String ns, 
         String prefix, String text, bool[] _attrPresenceFlags, 
         com.objsys.xbinder.runtime.XBContext xbContext) {
         if (base.decodeAttr(name, ns, prefix, text, _attrPresenceFlags, xbContext)) 
            return true;
         else  {
            return false;
         }
      }

      protected override void encodeAttrs(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         base.encodeAttrs(encoder, xbContext);
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element whose content  is to be decoded.
       * POST: if return is false, reader is on corresponding END_ELEMENT.
       *    if return is true, reader is positioned at first bit of unprocessed content.
       * @param decodeAllContent if true, an error occurs if any content is not decoded by this method.
       *    (ie, the return must be false)
       * @return true if more content remains to be decoded, false otherwise
       */
      protected override bool decodeContent(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool decodeAllContent) {
         try  {
            bool moreContent_4;
            moreContent_4 = base.decodeContent(reader, xbContext, false);
            if ( moreContent_4 ) {
               String elemLocalName = null;
               String elemNs = null;
               elemLocalName = reader.LocalName;
               elemNs = reader.NamespaceURI;

               // a_movementOrderId
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
               {
                  xbContext.decodeSchemaLocationAttrs(reader);
                  String text = reader.ReadString();
                  this.a_movementOrderId =  LongTextType.decode(text, xbContext);

                  _set_a_movementOrderId = true;

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // b_situation
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[1], elemNs, elemLocalName) )
               {
                  this.b_situation = new  NC1_MovOrder_ELEM_2_B_situation();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.b_situation.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // c_mission
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[2], elemNs, elemLocalName) )
               {
                  this.c_mission = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.c_mission.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // d_execution
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[3], elemNs, elemLocalName) )
               {
                  this.d_execution = new  NC1_MovOrder_ELEM_2_D_execution();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.d_execution.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // e_coordinationInstructions
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[4], elemNs, elemLocalName) )
               {
                  this.e_coordinationInstructions = new  NC1_MovOrder_ELEM_2_E_coordinationInstructions();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.e_coordinationInstructions.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // f_logisticsSupport
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[5], elemNs, elemLocalName) )
               {
                  this.f_logisticsSupport = new  NC1_MovOrder_ELEM_2_F_logisticsSupport();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.f_logisticsSupport.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // g_commandAndTransmissions
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[6], elemNs, elemLocalName) )
               {
                  this.g_commandAndTransmissions = new  NC1_MovOrder_ELEM_2_G_commandAndTransmissions();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.g_commandAndTransmissions.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // h_comment
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[7], elemNs, elemLocalName) )
               {
                  this.h_comment = new  CommentSectionType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.h_comment.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
                  if (moreContent_4) {
                     elemLocalName = reader.LocalName;
                     elemNs = reader.NamespaceURI;
                  }
               }

               // j_drafterUnitPoc
               if( moreContent_4 && XBQualifiedName.namesMatch(
                  (XBQualifiedName)particleInfo[8], elemNs, elemLocalName) )
               {
                  this.j_drafterUnitPoc = new  MixedAnyType();
                  xbContext.decodeSchemaLocationAttrs(reader);
                  this.j_drafterUnitPoc.decode(reader, xbContext, false, false);

                  moreContent_4 = 
                     XMLStreamHelper.moveToContentElement(reader);
               }

               if (decodeAllContent && moreContent_4) 
                  throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
            }
            return moreContent_4;
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode content.
       */
      protected override void encodeContent(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         base.encodeContent(encoder, xbContext);

         // a_movementOrderId
         if (_set_a_movementOrderId)  {
            encoder.encodeStartElement("A_movementOrderId", "", "");
            String text_4;
            text_4 =  LongTextType.encode(this.a_movementOrderId, xbContext);
            encoder.encodeChars(text_4);
            encoder.encodeEndElement();
         }

         // b_situation
         if (this.b_situation != null)  {
            encoder.encodeStartElement("B_situation", "", "");
            this.b_situation.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // c_mission
         if (this.c_mission != null)  {
            encoder.encodeStartElement("C_mission", "", "");
            this.c_mission.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // d_execution
         if (this.d_execution != null)  {
            encoder.encodeStartElement("D_execution", "", "");
            this.d_execution.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // e_coordinationInstructions
         if (this.e_coordinationInstructions != null)  {
            encoder.encodeStartElement("E_coordinationInstructions", "", "");
            this.e_coordinationInstructions.encode(encoder, xbContext, null, 
               false);
            encoder.encodeEndElement();
         }

         // f_logisticsSupport
         if (this.f_logisticsSupport != null)  {
            encoder.encodeStartElement("F_logisticsSupport", "", "");
            this.f_logisticsSupport.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // g_commandAndTransmissions
         if (this.g_commandAndTransmissions != null)  {
            encoder.encodeStartElement("G_commandAndTransmissions", "", "");
            this.g_commandAndTransmissions.encode(encoder, xbContext, null, 
               false);
            encoder.encodeEndElement();
         }

         // h_comment
         if (this.h_comment != null)  {
            encoder.encodeStartElement("H_comment", "", "");
            this.h_comment.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }

         // j_drafterUnitPoc
         if (this.j_drafterUnitPoc != null)  {
            encoder.encodeStartElement("J_drafterUnitPoc", "", "");
            this.j_drafterUnitPoc.encode(encoder, xbContext, null, false);
            encoder.encodeEndElement();
         }
      }


      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       * @param isNilled Pass true if the element was nillable and nilled.
       *       If true, an exception will result if any content is found.
       *       If false, an exception will result if non-emptiable particles
       *       are missing.
       * @param hasDefault Pass true if the element has a default fixed value.
       *       Clients are responsible for validating fixed values.
       *       If false, and isNilled is also false, an exception will result
       *       if no character data is found and no character data is invalid.
       *       If true, missing character data is ignored; you should have
       *       initialized the value field to the default value.
       */
      public override void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext, 
         bool isNilled, bool hasDefault) {

         //track presence of required, primitive type attrs
         bool[] _attrPresenceFlags = new bool[8];

         decodeNamespaces(reader);
         elementEmpty = XMLStreamHelper.checkEmptyElement(reader);

         for(bool moreAttr = reader.MoveToFirstAttribute(); moreAttr; 
            moreAttr = reader.MoveToNextAttribute()) {

            String text = reader.Value;
            String ns = reader.NamespaceURI;
            String name = reader.LocalName;
            String prefix = reader.Prefix;

            if (ns.CompareTo("http://www.w3.org/2001/XMLSchema-instance") == 0 ) continue;
            if (ns.CompareTo("http://www.w3.org/2000/xmlns/") == 0 ) continue;
            decodeAttr(name, ns, prefix, text, _attrPresenceFlags, xbContext);
         }
         validateAttrs(_attrPresenceFlags);

         if ( isNilled ) XMLStreamHelper.assertEmptyElement(reader);
         else  {
            decodeContent(reader, xbContext, true);
         }
      }


      /**
       * Encode contents of this class as XML content.
       * Caller should surround this method with calls to encoder.encodeStartElement 
       * and encoder.encodeEndElement.
       * @param elemDeclType if not null, encode xsi:type if this class's
       *    XSD_TYPE does not correspond to elemDeclType.
       * @param ignoreContent if true, do not encode, or validate, character
       *    data or child elements.  Encode an xsi:nil attribute.
       */
      public override void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext, 
         XBQualifiedName elemDeclType, bool ignoreContent) {

         encodeNamespaces(encoder);

         if ( elemDeclType != null && !XSD_TYPE.equals(elemDeclType) ) 
            encoder.encodeXsiType(XSD_TYPE);
         encodeAttrs(encoder, xbContext);
         if ( ignoreContent )  {
            encoder.encodeAttr("nil", "http://www.w3.org/2001/XMLSchema-instance", "xsi", "true");
            return;
         }

         encodeContent(encoder, xbContext);
      }
   }

   public class NC1_MovOrder_CC : XBDocumentCodec
   {
      public com.objsys.xbinder.runtime.XBContext _xbContext = new com.objsys.xbinder.runtime.XBContext();


      //particleInfo[i] provides information for the ith particle.
         //For elements, it is a XBQualifiedName, identifying the expected element.
      //For element wildcards, it is a String[], listing the allowed namespaces
      protected static  Object[] particleInfo = {
         new XBQualifiedName("urn:fra:nc1:message:movorder","NC1_MovOrder")
      };
      static NC1_MovOrder_CC() {
         XBUtil.license =  _NC1_MovOrder.license;
      }

      //Empty element indicator.  This variable may stay false
      //even if an element is empty because emptiness is
      //sometimes detected by another means.
      protected bool elementEmpty = false;

      //content fields
      protected  NC1_MovOrder_ELEM nC1_MovOrder;

      //content methods

      public  NC1_MovOrder_ELEM NC1_MovOrder
      {
         get
         {
            if (this.nC1_MovOrder == null)
                throw new XBException("field nC1_MovOrder not set");

            return this.nC1_MovOrder;
         }
         set
         {
            this.nC1_MovOrder = value;
         }
      }


      public void decodeDocument(XmlTextReader reader) {
         XMLStreamHelper.beginDocumentDecode(reader);
         decode(reader, _xbContext);
      }

      /**
       * Encode contents of this class as entire document.
       */
      public void encodeDocument(XBXmlEncoder encoder) {
         //To use the generated namespace prefixes do the following:
         //   encoder.setNamespaces(_NC1_MovOrder.namespaceContext);

         encoder.encodeStartDocument();
         encode(encoder, _xbContext);
      }

      /**
       * Decode from stream into this object.
       * PRE: reader is on START_ELEMENT of element to decode.
       * POST: reader is on corresponding END_ELEMENT.
       */
      public virtual void decode(XmlTextReader reader, com.objsys.xbinder.runtime.XBContext xbContext) 
      {
         xbContext.clearSchemaLocationAttrs();

         //decode content
         try  {
            String elemLocalName = null;
            String elemNs = null;
            elemLocalName = reader.LocalName;
            elemNs = reader.NamespaceURI;

            // nC1_MovOrder
            bool moreContent_4 = true;
            if( moreContent_4 && XBQualifiedName.namesMatch(
               (XBQualifiedName)particleInfo[0], elemNs, elemLocalName) )
            {
               this.nC1_MovOrder = new  NC1_MovOrder_ELEM();
               xbContext.decodeSchemaLocationAttrs(reader);
               this.nC1_MovOrder.decode(reader, xbContext, false, false);

               moreContent_4 = XMLStreamHelper.moveToContentElement(reader);
            }
            else if (moreContent_4) throw new XBUnexpectedElementException(elemNs, elemLocalName);
            else throw new XBOccurrencesException(0, "nC1_MovOrder");

            if (moreContent_4) 
               throw new XBUnexpectedElementException(reader.NamespaceURI, reader.LocalName);
         }
         catch( System.Xml.XmlException e )  {
            throw new XBException(e.ToString(), e);
         }
      }


      /**
       * Encode contents of this class as XML content.
       */
      public virtual void encode(XBXmlEncoder encoder, 
         com.objsys.xbinder.runtime.XBContext xbContext) {

         //encode content

         // nC1_MovOrder
         if (this.nC1_MovOrder == null)
             throw new XBException("field nC1_MovOrder not set");

         encoder.encodeStartElement("NC1_MovOrder",  _NC1_MovOrder.NS_URI,  _NC1_MovOrder.NS_PREFIX);
         xbContext.encodeSchemaLocationAttrs(encoder);
         this.nC1_MovOrder.encode(encoder, xbContext, null, false);
         encoder.encodeEndElement();
      }
   }
   /**
    * This file was generated by the Objective Systems XBinder(tm) Compiler
    * (http://www.obj-sys.com).  Version: 2.7.0, Date: 18-Jun-2022.
    * Copyright (c) 2003-2021 Objective Systems, Inc.
    *
    * Permission is hereby granted to redistribute this file with the
    * condition that this copyright notice be present and not altered.
    */

   public class _NC1_MovOrder {

      public static XBXmlNamespace[] namespaceContext = {
         new XBXmlNamespace("nc12dcoord", "urn:fra:nc1:objet:2dcoordinationmean")
         , new XBXmlNamespace("nc1common", "urn:fra:nc1:common:attribute"), 
         new XBXmlNamespace("nc1sicsdicos", "urn:fra:nc1:common:sicsdicos"), 
         new XBXmlNamespace("nc1objcom", "urn:fra:nc1:common:object"), 
         new XBXmlNamespace("nc1cbrn", "urn:fra:nc1:common:cbrn"), 
         new XBXmlNamespace("nc1location", "urn:fra:nc1:common:location"), 
         new XBXmlNamespace("nc1com", "urn:fra:nc1:common:communication"), 
         new XBXmlNamespace("nc1ew", "urn:fra:nc1:common:ew"), 
         new XBXmlNamespace("nc1msgcom", "urn:fra:nc1:common:message"), 
         new XBXmlNamespace("nc13droute", "urn:fra:nc1:objet:3droute"), 
         new XBXmlNamespace("nc1acm", "urn:fra:nc1:objet:acm"), 
         new XBXmlNamespace("nc1airparticipant", "urn:fra:nc1:objet:airparticipant")
         , new XBXmlNamespace("nc1logistics", "urn:fra:nc1:common:logistics"), 
         new XBXmlNamespace("nc1participant", "urn:fra:nc1:objet:participant")
         , new XBXmlNamespace("nc1airtrack", "urn:fra:nc1:objet:airtrack"), 
         new XBXmlNamespace("nc1track", "urn:fra:nc1:objet:track"), 
         new XBXmlNamespace("nc1cbrnevent", "urn:fra:nc1:objet:cbrnevent"), 
         new XBXmlNamespace("nc1convoy", "urn:fra:nc1:objet:convoy"), 
         new XBXmlNamespace("nc1event", "urn:fra:nc1:objet:event"), 
         new XBXmlNamespace("nc1medical", "urn:fra:nc1:common:health"), 
         new XBXmlNamespace("nc1facility", "urn:fra:nc1:objet:facility"), 
         new XBXmlNamespace("nc1fire", "urn:fra:nc1:objet:fire"), 
         new XBXmlNamespace("nc1fireobjective", "urn:fra:nc1:objet:fireobjective")
         , new XBXmlNamespace("nc1freeshape", "urn:fra:nc1:objet:freeshape"), 
         new XBXmlNamespace("nc1groundentity", "urn:fra:nc1:objet:groundentity")
         , 
         new XBXmlNamespace("nc1groundparticipant", "urn:fra:nc1:objet:groundparticipant")
         , 
         new XBXmlNamespace("nc1groundtrack", "urn:fra:nc1:objet:groundtrack")
         , 
         new XBXmlNamespace("nc1iffprocedure", "urn:fra:nc1:objet:iffprocedure")
         , new XBXmlNamespace("nc1individual", "urn:fra:nc1:objet:individual")
         , 
         new XBXmlNamespace("nc1intelreq", "urn:fra:nc1:objet:intelrequirement")
         , new XBXmlNamespace("nc1meteo", "urn:fra:nc1:objet:meteo"), 
         new XBXmlNamespace("nc1mission", "urn:fra:nc1:objet:mission"), 
         new XBXmlNamespace("nc1missionASA", "urn:fra:nc1:objet:missionASA"), 
         new XBXmlNamespace("nc1missionASS", "urn:fra:nc1:objet:missionASS"), 
         new XBXmlNamespace("nc1obstacle", "urn:fra:nc1:objet:obstacle"), 
         new XBXmlNamespace("nc1organisation", "urn:fra:nc1:objet:organisation")
         , 
         new XBXmlNamespace("nc1reinforcement", "urn:fra:nc1:objet:reinforcement")
         , new XBXmlNamespace("nc1roe", "urn:fra:nc1:objet:roe"), 
         new XBXmlNamespace("nc1route", "urn:fra:nc1:objet:route"), 
         new XBXmlNamespace("nc1seaparticipant", "urn:fra:nc1:objet:seaparticipant")
         , new XBXmlNamespace("nc1seatrack", "urn:fra:nc1:objet:seatrack"), 
         new XBXmlNamespace("nc1tacarea", "urn:fra:nc1:objet:tacarea"), 
         new XBXmlNamespace("nc1tacline", "urn:fra:nc1:objet:tacline"), 
         new XBXmlNamespace("nc1tacpoint", "urn:fra:nc1:objet:tacpoint"), 
         new XBXmlNamespace("nc1unit", "urn:fra:nc1:objet:unit"), 
         new XBXmlNamespace("nc1admitexitrep", "urn:fra:nc1:message:admitexitrep")
         , 
         new XBXmlNamespace("nc1annultirinterdit", "urn:fra:nc1:message:annultirinterdit")
         , new XBXmlNamespace("nc1apercu", "urn:fra:nc1:message:apercu"), 
         new XBXmlNamespace("nc1apercu3d", "urn:fra:nc1:message:apercu3d"), 
         new XBXmlNamespace("nc1barrep", "urn:fra:nc1:message:barrep"), 
         new XBXmlNamespace("nc1batrecevacreq", "urn:fra:nc1:message:batrecevacreq")
         , new XBXmlNamespace("nc1bda", "urn:fra:nc1:message:bda"), 
         new XBXmlNamespace("nc1bft", "urn:fra:nc1:message:bft"), 
         new XBXmlNamespace("nc1boap", "urn:fra:nc1:message:boap"), 
         new XBXmlNamespace("nc1technoap", "urn:fra:nc1:message:technoap"), 
         new XBXmlNamespace("nc1barreq", "urn:fra:nc1:message:barreq"), 
         new XBXmlNamespace("cbrn1bio", "urn:fra:nc1:message:cbrn1bio"), 
         new XBXmlNamespace("nc1cbrn1chem", "urn:fra:nc1:message:cbrn1chem"), 
         new XBXmlNamespace("nc1cbrn3bio", "urn:fra:nc1:message:cbrn3bio"), 
         new XBXmlNamespace("nc1cbrn3chem", "urn:fra:nc1:message:cbrn3chem"), 
         new XBXmlNamespace("nc1cbrn4bio", "urn:fra:nc1:message:cbrn4bio"), 
         new XBXmlNamespace("nc1cbrn4chem", "urn:fra:nc1:message:cbrn4chem"), 
         new XBXmlNamespace("nc1cbrn5bio", "urn:fra:nc1:message:cbrn5bio"), 
         new XBXmlNamespace("nc1cbrn5chem", "urn:fra:nc1:message:cbrn5chem"), 
         new XBXmlNamespace("nc1cbrncdr", "urn:fra:nc1:message:cbrncdr"), 
         new XBXmlNamespace("nc1cbrnsitrep", "urn:fra:nc1:message:cbrnsitrep")
         , new XBXmlNamespace("nc1ccacard", "urn:fra:nc1:message:ccacard"), 
         new XBXmlNamespace("nc1cff", "urn:fra:nc1:message:callforfire"), 
         new XBXmlNamespace("nc1conarep", "urn:fra:nc1:message:conarep"), 
         new XBXmlNamespace("nc1conops", "urn:fra:nc1:message:conops"), 
         new XBXmlNamespace("nc1opord", "urn:fra:nc1:message:opord"), 
         new XBXmlNamespace("nc1creationitsats", "urn:fra:nc1:message:creationitsats")
         , new XBXmlNamespace("nc1deployrep", "urn:fra:nc1:message:deployrep")
         , new XBXmlNamespace("nc1demalord", "urn:fra:nc1:message:demalord"), 
         new XBXmlNamespace("nc1engrecceord", "urn:fra:nc1:message:engrecceord")
         , 
         new XBXmlNamespace("nc1engreccerep", "urn:fra:nc1:message:engreccerep")
         , new XBXmlNamespace("nc1ensitrep", "urn:fra:nc1:message:ensitrep"), 
         new XBXmlNamespace("nc1eoincrep", "urn:fra:nc1:message:eoincrep"), 
         new XBXmlNamespace("nc1eventrep", "urn:fra:nc1:message:eventrep"), 
         new XBXmlNamespace("nc1ewmsnsum", "urn:fra:nc1:message:ewmsnsum"), 
         new XBXmlNamespace("nc1ewrtm", "urn:fra:nc1:message:ewrtm"), 
         new XBXmlNamespace("nc1finalertraideni", "urn:fra:nc1:message:finalerteraideni")
         , 
         new XBXmlNamespace("nc1firecontrol", "urn:fra:nc1:message:firecontrol")
         , 
         new XBXmlNamespace("nc1firereport", "urn:fra:nc1:message:firereport")
         , new XBXmlNamespace("nc1helopsum", "urn:fra:nc1:message:helopsum"), 
         new XBXmlNamespace("nc1igen", "urn:fra:nc1:message:igen"), 
         new XBXmlNamespace("nc1intrep", "urn:fra:nc1:message:intrep"), 
         new XBXmlNamespace("nc1intreq", "urn:fra:nc1:message:intreq"), 
         new XBXmlNamespace("nc1intsum", "urn:fra:nc1:message:intsum"), 
         new XBXmlNamespace("nc1initmedrep", "urn:fra:nc1:message:initmedrep")
         , new XBXmlNamespace("nc1initodb", "urn:fra:nc1:message:initodb"), 
         new XBXmlNamespace("nc1ler", "urn:fra:nc1:message:ler"), 
         new XBXmlNamespace("nc1medevac", "urn:fra:nc1:message:medevac"), 
         new XBXmlNamespace("nc1matdem", "urn:fra:nc1:message:matdem"), 
         new XBXmlNamespace("nc1medsitrep", "urn:fra:nc1:message:medsitrep"), 
         new XBXmlNamespace("nc1messagelibre", "urn:fra:nc1:message:messagelibre")
         , new XBXmlNamespace("nc1movorder", "urn:fra:nc1:message:movorder"), 
         new XBXmlNamespace("nc1obsexord", "urn:fra:nc1:message:obsexord"), 
         new XBXmlNamespace("nc1opordain", "urn:fra:nc1:message:opordain"), 
         new XBXmlNamespace("nc1opordalat", "urn:fra:nc1:message:opordalat"), 
         new XBXmlNamespace("nc1opordge", "urn:fra:nc1:message:opordge"), 
         new XBXmlNamespace("nc1opordgen", "urn:fra:nc1:message:opordgen"), 
         new XBXmlNamespace("nc1opordlog", "urn:fra:nc1:message:opordlog"), 
         new XBXmlNamespace("nc1opordmvt", "urn:fra:nc1:message:opordmvt"), 
         new XBXmlNamespace("nc1opordopsec", "urn:fra:nc1:message:opordopsec")
         , new XBXmlNamespace("nc1opordrens", "urn:fra:nc1:message:opordrens")
         , new XBXmlNamespace("nc1opordroe", "urn:fra:nc1:message:opordroe"), 
         new XBXmlNamespace("nc1opordsic", "urn:fra:nc1:message:opordsic"), 
         new XBXmlNamespace("nc1ownsitrep", "urn:fra:nc1:message:ownsitrep"), 
         new XBXmlNamespace("nc1objectivelist", "urn:fra:nc1:message:objectivelist")
         , new XBXmlNamespace("nc1pema", "urn:fra:nc1:message:pema"), 
         new XBXmlNamespace("nc1prr", "urn:fra:nc1:message:prr"), 
         new XBXmlNamespace("nc1plandevol", "urn:fra:nc1:message:plandevol"), 
         new XBXmlNamespace("nc1propplanobst", "urn:fra:nc1:message:propplanobstacles")
         , new XBXmlNamespace("nc1request", "urn:fra:nc1:message:request"), 
         new XBXmlNamespace("nc1str", "urn:fra:nc1:message:str"), 
         new XBXmlNamespace("nc1sitobst", "urn:fra:nc1:message:sitobst"), 
         new XBXmlNamespace("nc1stacmconduite", "urn:fra:nc1:message:stacmconduite")
         , 
         new XBXmlNamespace("nc1suppritsats", "urn:fra:nc1:message:suppressionitsats")
         , new XBXmlNamespace("nc1tactoap", "urn:fra:nc1:message:tactoap"), 
         new XBXmlNamespace("nc1techreqinfo", "urn:fra:nc1:service:reqinfo"), 
         new XBXmlNamespace("nc1stcupdate", "urn:fra:nc1:service:stcupdate"), 
         new XBXmlNamespace("nc1tirinterdit", "urn:fra:nc1:message:tirinterdit")
         };

      //declare constants for the schema's ns and preferred prefix
      public static readonly String NS_URI = "urn:fra:nc1:message:movorder";
      public static readonly String NS_PREFIX = "nc1movorder";

      /* Runtime License expiration: Sun Jul 17 06:45:01 2022
 */
      public static readonly byte[] license = {
         0x54, (byte)0xa9, 0x52, (byte)0xa5, 0x62, (byte)0xd3, (byte)0x93, 
            (byte)0xcd} ;

      public static XBDoubleFormat defaultDoubleFmt = new XBDoubleFormat();

      public _NC1_MovOrder() {
      }
      static _NC1_MovOrder() {
         XBUtil.license = _NC1_MovOrder.license;
      }
   }
}
