﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common.msg;
using Commun.msg;
using Commun.Commun;
using msg;

namespace MyMissionPlaner.Models.NC1Components
{
    public class NC1_STR :  NC1_STR_ELEM {}

    public class NC1_StAcmConduite :     NC1_StAcmConduite_ELEM {}
    public class NC1_OWNSITREP : NC1_OWNSITREP_ELEM {}
    public class NC1_MessageLibre : NC1_MessageLibre_ELEM {}

    public class NC1_ListeEquipementsRessources : NC1_ListeEquipementsRessources_ELEM {}
    public class NC1_INTSUM : NC1_INTSUM_ELEM{}
    public class NC1_SitObst : NC1_SitObst_ELEM {}
    public class NC1_INTREQ : NC1_INTREQ_ELEM {}
    public class NC1_Apercu : NC1_Apercu_ELEM { }
    public class NC1_INTREP : NC1_INTREP_ELEM { }
    public class NC1_InitOdb : NC1_InitOdb_ELEM { }
    public class NC1_EVENTREP : NC1_EVENTREP_ELEM { }
    public class NC1_BFT : NC1_BFT_ELEM { }
    public class NC1_BARREP : NC1_BARREP_ELEM { }
    public class NC1_Apercu3D : NC1_Apercu3D_ELEM { }
    public class NC1_PRR : NC1_PRR_ELEM { }
    public class NC1_PEMA : NC1_PEMA_ELEM { }


}